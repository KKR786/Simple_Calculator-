package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView screen;
    private Button ac,negetive,power,divide,plus,minus,multi,zero,one,two,three,four,five,six,seven,eight,nine,equal,point,back,percent;
    private String input,ans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        screen = findViewById(R.id.screen);
        ac = findViewById(R.id.ac);
        negetive = findViewById(R.id.negetive);
        power = findViewById(R.id.power);
        divide = findViewById(R.id.divide);
        plus = findViewById(R.id.plus);
        minus = findViewById(R.id.minus);
        multi = findViewById(R.id.multi);
        zero = findViewById(R.id.zero);
        one = findViewById(R.id.one);
        two = findViewById(R.id.two);
        three = findViewById(R.id.three);
        four = findViewById(R.id.four);
        five = findViewById(R.id.five);
        six = findViewById(R.id.six);
        seven = findViewById(R.id.seven);
        eight = findViewById(R.id.eight);
        nine = findViewById(R.id.nine);
        equal = findViewById(R.id.equal);
        point = findViewById(R.id.point);
        back = findViewById(R.id.back);
        percent = findViewById(R.id.percent);

    }
    public void btnClick(View v) {
        Button btn = (Button) v;
        String data = btn.getText().toString();
        switch (data){
            case"AC":
                input = "";
                break;
            case"=":
                solution();
                ans = input;
                break;
            case"+/-":
                input = "-";
                break;
            case"^":
                solution();
                input+="^";
                break;
            case"CE":
                String str = input.substring(0,input.length()-1);
                input = str;
                break;
            case"%":
                solution();
                input+="%";
                break;
            default:
                if(input==null){
                    input = "";
                }
                if(data.equals("+")||data.equals("-")||data.equals("*")||data.equals("/")){
                    solution();
                }
                input+=data;
        }
        screen.setText(input);
    }

    private void solution(){
        if(input.split("\\*").length==2){
            String num[] = input.split("\\*");
            try {
                double multi = Double.parseDouble(num[0])*Double.parseDouble(num[1]);
                input = multi+"";
            }
            catch (Exception e) {

            }
        }
        else if(input.split("/").length==2){
            String num[] = input.split("/");
            try {
                double divide = Double.parseDouble(num[0])/Double.parseDouble(num[1]);
                input = divide+"";
            }
            catch (Exception e) {

            }
        }
        else if(input.split("\\+").length==2){
            String num[] = input.split("\\+");
            try {
                double plus = Double.parseDouble(num[0])+Double.parseDouble(num[1]);
                input = plus+"";
            }
            catch (Exception e) {

            }
        }
        else if(input.split("-").length>1){
            String num[] = input.split("-");
            if(num[0]=="" && num.length==2){
                num[0]=0+"";
            }
            try {
                double minus = 0;
                if(num.length==2) {
                    minus = Double.parseDouble(num[0]) - Double.parseDouble(num[1]);
                }
                else if(num.length==3){
                    minus = -Double.parseDouble(num[1])-Double.parseDouble(num[2]);
                }
                input = minus+"";
            }
            catch (Exception e) {

            }
        }
        else if(input.split("\\^").length==2){
            String num[] = input.split("\\^");
            try {
                double power = Math.pow (Double.parseDouble(num[0]),Double.parseDouble(num[1]));
                input = power+"";
            }
            catch (Exception e) {

            }
        }
        else if(input.split("%").length==2){
            String num[] = input.split("%");
            try {
                double percent =(Double.parseDouble(num[0])*Double.parseDouble(num[1]))/100;
                input = percent+"";
            }
            catch (Exception e) {

            }
        }

        String n[] = input.split("\\.");
        if(n.length>1) {
            if (n[1].equals("0")) {
                input = n[0];
            }
        }
        screen.setText(input);
    }
}